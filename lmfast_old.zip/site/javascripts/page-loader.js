/**
 * Page Loader - Simple loading indicator
 * NO NAVBAR FUNCTIONALITY
 */

(function() {
    'use strict';
    
    const loaderHTML = `
        <div id="page-loader" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.9);z-index:9999;align-items:center;justify-content:center;">
            <div style="width:40px;height:40px;border:3px solid #e2e8f0;border-top-color:#3b82f6;border-radius:50%;animation:spin 0.8s linear infinite;"></div>
        </div>
        <style>@keyframes spin{to{transform:rotate(360deg);}}</style>
    `;
    
    let loader = null;
    
    function showLoader() {
        if (!loader) {
            document.body.insertAdjacentHTML('afterbegin', loaderHTML);
            loader = document.getElementById('page-loader');
        }
        if (loader) loader.style.display = 'flex';
    }
    
    function hideLoader() {
        if (loader) loader.style.display = 'none';
    }
    
    function init() {
        if (document.readyState === 'complete') {
            hideLoader();
        } else {
            window.addEventListener('load', hideLoader, { once: true });
        }
        
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (link && link.href && !link.target && !link.download) {
                try {
                    const url = new URL(link.href);
                    if (url.origin === window.location.origin) {
                        showLoader();
                    }
                } catch (err) {}
            }
        }, { passive: true });
        
        window.addEventListener('pageshow', (e) => {
            if (e.persisted) hideLoader();
        }, { passive: true });
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
