/**
 * Sidebar Enhancer - Clean up chapter titles
 * NO NAVBAR FUNCTIONALITY
 */

(function() {
    'use strict';
    
    function cleanupTitles() {
        requestAnimationFrame(() => {
            const links = document.querySelectorAll('.md-nav__link');
            
            links.forEach(link => {
                const text = link.textContent.trim();
                const cleaned = text
                    .replace(/^Chapter\s+\d+:\s*/i, '')
                    .replace(/^Chapter\s+\d+\s*-\s*/i, '')
                    .replace(/^Chapter\s+\d+\s+/i, '');
                
                if (cleaned !== text && cleaned.length > 0) {
                    link.textContent = cleaned;
                }
            });
        });
    }
    
    function init() {
        cleanupTitles();
        
        const sidebar = document.querySelector('.md-sidebar--primary');
        if (sidebar) {
            const observer = new MutationObserver(() => {
                setTimeout(cleanupTitles, 100);
            });
            observer.observe(sidebar, { childList: true, subtree: true });
        }
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
