/**
 * Page Layout Enhancer - Hide sidebar for specific pages
 * NO NAVBAR FUNCTIONALITY
 */

(function() {
    'use strict';
    
    const NO_SIDEBAR_PAGES = ['/community/', '/about/', '/contributing/'];
    
    function shouldHideSidebar() {
        const path = window.location.pathname;
        return NO_SIDEBAR_PAGES.some(page => path.includes(page));
    }
    
    function adjustLayout() {
        if (!shouldHideSidebar()) return;
        
        requestAnimationFrame(() => {
            const sidebar = document.querySelector('.md-sidebar--primary');
            const content = document.querySelector('.md-content');
            const contentInner = document.querySelector('.md-content__inner');
            
            if (sidebar) sidebar.style.display = 'none';
            if (content) {
                content.style.marginLeft = '0';
                content.style.maxWidth = '100%';
            }
            if (contentInner) {
                contentInner.style.maxWidth = '1200px';
                contentInner.style.margin = '0 auto';
                contentInner.style.paddingLeft = window.innerWidth <= 768 ? '1.5rem' : '3rem';
                contentInner.style.paddingRight = window.innerWidth <= 768 ? '1.5rem' : '3rem';
            }
        });
    }
    
    function init() {
        adjustLayout();
        
        if (typeof app !== 'undefined' && app.document$) {
            app.document$.subscribe(() => requestAnimationFrame(adjustLayout));
        }
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
