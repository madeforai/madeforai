/**
 * MadeForAI - Navbar Disabled
 * All navbar functionality removed
 */

(function() {
    'use strict';
    console.log('MadeForAI: Navbar disabled - no header/tabs shown');
})();
