# 🚀 MadeForAI - Master the GenAI Frontier

[![Deploy Status](https://github.com/madeforai/madeforai/workflows/Deploy%20MadeForAI%20to%20GitHub%20Pages/badge.svg)](https://github.com/madeforai/madeforai/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

The definitive guide to Generative AI engineering. From prompt engineering basics to scalable architecture optimization for enterprise.

## ✨ Features

- 🎓 **5 Comprehensive Learning Paths** - From absolute beginner to AI innovator
- 📓 **Interactive Jupyter Notebooks** - Learn by doing with executable code
- 🎨 **Beautiful, Modern UI** - Optimized reading experience with Material Design
- 🔗 **Open in Colab** - One-click access to Google Colab for all notebooks
- 🎯 **Progressive Learning** - Carefully structured curriculum for each persona
- 🔄 **Always Up-to-Date** - Latest techniques and best practices for 2026
- 🌐 **Production-Ready** - Real-world applications and deployment guides
- 💬 **Community-Driven** - Join 5,000+ AI engineers on Discord

## 🎓 Learning Paths

### Understanding AI: Absolute Beginner → AI Enthusiast (4-6 weeks)
- Introduction to AI, ML, and Deep Learning
- Understanding Neural Networks
- What are LLMs?
- Your First LLM Application
- Prompt Engineering Basics

### Engineering AI: Developer → LLM Engineer (8-12 weeks)
- Transformer Architecture Deep Dive
- Tokenization & Embeddings
- Attention Mechanisms
- Fine-tuning with LoRA/QLoRA
- RAG Systems
- LLM Deployment & Optimization
- Production MLOps

### Researching AI: ML Engineer → LLM Specialist (10-16 weeks)
- LLM Pre-training from Scratch
- Advanced Architecture Patterns
- Distributed Training
- Model Compression & Quantization
- KV Cache Optimization
- Advanced RAG Techniques
- Agentic Systems & MCP
- LLMOps & Monitoring

### Architecting AI: Researcher → AI Innovator (12-20 weeks)
- State-of-the-Art Architectures (2025-2026)
- Novel Training Techniques
- Multimodal Models
- Constitutional AI & Alignment
- Efficient Transformers
- Research Reproduction
- Paper Implementation
- Publishing & Open Source

### Business AI: Business Leader → AI Strategist (4-6 weeks)
- AI/LLM Landscape Overview
- Use Cases & ROI
- Build vs Buy vs Fine-tune
- Security & Compliance
- Team Building & Talent
- Vendor Evaluation
- Implementation Roadmap
- Future Trends

## 🚀 Quick Start

### Prerequisites

- Python 3.9 or higher
- pip package manager
- Git

### Local Development

1. **Clone the repository**

```bash
git clone https://github.com/madeforai/madeforai.git
cd madeforai
```

2. **Install dependencies**

```bash
pip install -r requirements.txt
```

3. **Run the development server**

```bash
mkdocs serve
```

4. **Open in browser**

Navigate to `http://127.0.0.1:8000`

### Building for Production

```bash
mkdocs build
```

The site will be built in the `site/` directory.

## 📁 Project Structure

```
madeforai/
├── docs/
│   ├── index.md                      # Homepage
│   ├── getting-started/              # Getting Started guides
│   ├── paths/                        # Learning paths
│   │   ├── understanding-ai/         # Understanding AI
│   │   ├── engineering-ai/           # Engineering AI
│   │   ├── researching-ai/           # Researching AI
│   │   ├── architecting-ai/          # Architecting AI
│   │   └── business-ai/              # Business AI
│   ├── resources/                    # Additional resources
│   ├── community/                    # Community pages
│   ├── about/                        # About pages
│   ├── stylesheets/                  # Custom CSS
│   └── javascripts/                  # Custom JS
├── .github/
│   └── workflows/
│       └── deploy.yml                # GitHub Actions workflow
├── mkdocs.yml                        # MkDocs configuration
├── requirements.txt                  # Python dependencies
└── README.md                         # This file
```

## 🔧 Technology Stack

- **[MkDocs](https://www.mkdocs.org/)** - Static site generator
- **[Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)** - Beautiful theme
- **[mkdocs-jupyter](https://github.com/danielfrg/mkdocs-jupyter)** - Native Jupyter notebook support
- **[GitHub Pages](https://pages.github.com/)** - Free hosting
- **[GitHub Actions](https://github.com/features/actions)** - Automated deployment

## 📝 Contributing

We welcome contributions! Here's how you can help:

1. **Report bugs** - Open an issue describing the bug
2. **Suggest features** - Share your ideas for new content or features
3. **Submit notebooks** - Contribute new learning modules
4. **Improve documentation** - Fix typos, improve explanations
5. **Share feedback** - Tell us what's working and what's not

### Contribution Guidelines

1. Fork the repository
2. Create a new branch (`git checkout -b feature/amazing-module`)
3. Make your changes
4. Test locally with `mkdocs serve`
5. Commit your changes (`git commit -m 'Add amazing module'`)
6. Push to the branch (`git push origin feature/amazing-module`)
7. Open a Pull Request

## 🌐 Deployment

The site is automatically deployed to GitHub Pages on every push to the `main` branch using GitHub Actions.

### Manual Deployment

```bash
mkdocs gh-deploy --force
```

## 📖 Documentation

- [MkDocs Documentation](https://www.mkdocs.org/)
- [Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)
- [mkdocs-jupyter Plugin](https://github.com/danielfrg/mkdocs-jupyter)

## 🤝 Community

- **Discord** - [Join our server](https://discord.gg/madeforai) for real-time discussions
- **GitHub Discussions** - Ask questions and share ideas
- **Twitter** - [@madeforai](https://twitter.com/madeforai) for updates

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- All contributors who help improve the content
- The open-source community for amazing tools
- Our Discord community for feedback and support

## 📧 Contact

- Website: [https://madeforai.github.io/madeforai](https://madeforai.github.io/madeforai)
- Email: contact@madeforai.com
- Twitter: [@madeforai](https://twitter.com/madeforai)

---

**Made with ❤️ by the MadeForAI Team**

⭐ Star us on GitHub if you find this useful!